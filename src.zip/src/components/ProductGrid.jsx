import { useSelector, useDispatch } from 'react-redux'
import ProductCard from './ProductCard'
import Pagination from './Pagination'
import { setPage } from '../store/slices/productsSlice'

export default function ProductGrid() {
  const dispatch = useDispatch()
  const { filteredItems, page, limit } = useSelector((state) => state.products)

  const start = (page - 1) * limit
  const paginated = filteredItems.slice(start, start + limit)

  return (
    <div className="flex flex-col items-center">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {paginated.map((item) => (
          <ProductCard key={item.id} item={item} />
        ))}
      </div>

      <Pagination
        page={page}
        total={filteredItems.length}
        limit={limit}
        onChange={(p) => dispatch(setPage(p))}
      />
    </div>
  )
}

import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useSelector } from 'react-redux'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import {
  AiOutlineShoppingCart,
  AiOutlineHeart,
  AiOutlineUser,
  AiOutlineSearch,
  AiOutlineMenu,
  AiOutlineClose,
  AiOutlineHome,
  AiOutlineAppstore
} from 'react-icons/ai'
import MenuToggle from './MenuToggle'

export default function Header() {
  const { t, i18n } = useTranslation()
  const totalQty = useSelector((s) => s.cart.totalQty)
  const navigate = useNavigate()
  const location = useLocation()

  const [scrolled, setScrolled] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const [showAuth, setShowAuth] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const changeLng = (e) => {
    const lng = e.target.value
    i18n.changeLanguage(lng)
    localStorage.setItem('lng', lng)
  }

  const navLinks = [
    { label: t('home'), path: '/' },
    { label: t('products'), path: '/products' },
    { label: t('about'), path: '/about' },
    { label: t('contact'), path: '/contact' },
  ]

  return (
    <>
      {/* ===== HEADER TOP ===== */}
      <header
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-brand-dark/90 backdrop-blur-md shadow-lg' : 'bg-brand-dark'
          }`}
      >
        <div className="max-w-[1300px] mx-auto flex items-center justify-between px-4 py-3 text-white">
          {/* Left — Logo */}
          <Link to="/" className="flex items-center gap-2 hover:opacity-90 transition">
            <img src="/src/assets/logo.svg" alt="logo" className="h-7 w-7 object-contain" />
            <span className="font-semibold text-lg">BitSoft</span>
          </Link>

          {/* Center — Nav links (tablet/laptop) */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`hover:text-brand-accent transition ${location.pathname === link.path ? 'text-brand-accent' : 'text-white'
                  }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Right — Icons */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Search */}
            <button
              onClick={() => setShowSearch(!showSearch)}
              className="p-2 hover:bg-white/10 rounded transition"
            >
              {showSearch ? <AiOutlineClose size={20} /> : <AiOutlineSearch size={20} />}
            </button>

            {/* Language */}
            <select
              onChange={changeLng}
              defaultValue={i18n.language}
              className="bg-transparent border border-white/30 text-xs rounded px-1.5 py-0.5 focus:outline-none"
            >
              <option value="uz">UZ</option>
              <option value="en">EN</option>
            </select>

            {/* Like */}
            <button
              onClick={() => navigate('/wishlist')}
              className="hidden sm:hidden md:block relative p-2 hover:bg-white/10 rounded transition"
            >
              <AiOutlineHeart size={20} />
            </button>

            {/* Cart */}
            <button
              onClick={() => navigate('/cart')}
              className="hidden sm:hidden md:block relative p-2 hover:bg-white/10 rounded transition"
            >
              <AiOutlineShoppingCart size={20} />
              {totalQty > 0 && (
                <span className="absolute -top-1 -right-1 bg-brand-accent text-[10px] px-1 rounded">
                  {totalQty}
                </span>
              )}
            </button>


            <MenuToggle />

          </div>
        </div>

        {/* Search Bar */}
        {showSearch && (
          <div className="bg-white shadow-md flex items-center gap-2 px-4 py-2">
            <AiOutlineSearch className="text-gray-500" size={18} />
            <input
              type="text"
              placeholder={t('search_placeholder')}
              className="flex-1 text-sm text-gray-800 outline-none"
            />
          </div>
        )}

        {/* Mobile Menu */}
        <div
          className={`md:hidden bg-white text-gray-900 overflow-hidden shadow-inner transition-all duration-300 ${showMenu ? 'max-h-[400px] opacity-100' : 'max-h-0 opacity-0'
            }`}
        >
          <div className="flex flex-col px-5 py-3 text-sm font-medium divide-y divide-gray-200">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setShowMenu(false)}
                className={`py-2 ${location.pathname === link.path
                  ? 'text-brand-primary font-medium'
                  : 'hover:text-brand-accent'
                  }`}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </header>

      <div className="h-[64px]" />

      {/* ===== MOBILE BOTTOM MENU ===== */}
      <div className="md:hidden fixed bottom-0 left-0 w-full bg-white border-t border-gray-200 flex justify-around py-2 z-50">
        <button
          onClick={() => navigate('/')}
          className={`flex flex-col items-center text-[11px] ${location.pathname === '/' ? 'text-brand-primary' : 'text-gray-600'
            }`}
        >
          <AiOutlineHome size={22} />
          Home
        </button>

        <button
          onClick={() => navigate('/products')}
          className={`flex flex-col items-center text-[11px] ${location.pathname === '/products' ? 'text-brand-primary' : 'text-gray-600'
            }`}
        >
          <AiOutlineAppstore size={22} />
          Products
        </button>

        <button
          onClick={() => navigate('/wishlist')}
          className={`flex flex-col items-center text-[11px] ${location.pathname === '/wishlist' ? 'text-brand-primary' : 'text-gray-600'
            }`}
        >
          <AiOutlineHeart size={22} />
          Like
        </button>

        <button
          onClick={() => navigate('/cart')}
          className="relative flex flex-col items-center text-[11px] text-gray-600"
        >
          <AiOutlineShoppingCart size={22} />
          {totalQty > 0 && (
            <span className="absolute top-0 right-3 bg-brand-accent text-white text-[10px] px-1 rounded-full">
              {totalQty}
            </span>
          )}
          Cart
        </button>

        <button
          onClick={() => setShowAuth(true)}
          className="flex flex-col items-center text-[11px] text-gray-600"
        >
          <AiOutlineUser size={22} />
          Account
        </button>
      </div>

      {/* AUTH MODAL */}
      {showAuth && (
        <div
          onClick={() => setShowAuth(false)}
          className="fixed inset-0 bg-black/40 z-50 flex justify-center items-center"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-xl shadow-lg w-[90%] sm:w-[400px] p-6 text-center"
          >
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Welcome</h3>
            <div className="flex flex-col gap-3">
              <button className="w-full py-2 bg-brand-primary text-white rounded-md hover:bg-brand-accent transition">
                Sign In
              </button>
              <button className="w-full py-2 border border-gray-300 rounded-md hover:bg-gray-100 transition">
                Create Account
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

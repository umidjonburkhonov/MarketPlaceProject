import { useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { useState, useMemo, useEffect, useRef } from 'react'
import FilterSidebar from '../components/FilterSidebar'
import ProductCard from '../components/ProductCard'
import { FiFilter } from 'react-icons/fi'

export default function ProductsPage() {
    const { items, selectedCategory, selectedSubCategory } = useSelector((s) => s.products)
    const [priceRange, setPriceRange] = useState([0, 10000])
    const [isFilterOpen, setIsFilterOpen] = useState(false)
    const [visibleCount, setVisibleCount] = useState(10)
    const [loading, setLoading] = useState(false)
    const loaderRef = useRef(null)
    const navigate = useNavigate()

    const filtered = useMemo(() => {
        const [min, max] = priceRange
        return items.filter(
            (p) =>
                (!selectedCategory || p.category === selectedCategory) &&
                (!selectedSubCategory || p.subCategory === selectedSubCategory) &&
                p.price >= min &&
                p.price <= max
        )
    }, [items, selectedCategory, selectedSubCategory, priceRange])

    const visibleProducts = filtered.slice(0, visibleCount)

    useEffect(() => {
        if (loading) return
        const observer = new IntersectionObserver(
            (entries) => {
                if (entries[0].isIntersecting && visibleCount < filtered.length) {
                    setLoading(true)
                    setTimeout(() => {
                        setVisibleCount((prev) => prev + 10)
                        setLoading(false)
                    }, 600)
                }
            },
            { threshold: 1.0 }
        )
        if (loaderRef.current) observer.observe(loaderRef.current)
        return () => observer.disconnect()
    }, [visibleCount, filtered.length, loading])

    useEffect(() => {
        setVisibleCount(10)
    }, [selectedCategory, selectedSubCategory, priceRange])

    return (
        <div className="min-h-screen flex bg-gray-50 dark:bg-gray-900">
            {/* Desktop Sidebar */}
            <div className="hidden md:block w-64">
                <FilterSidebar onPriceChange={setPriceRange} />
            </div>

            {/* Main */}
            <main className="flex-1 p-5">
                {/* Filter Button (Mobile) */}
                <div className="md:hidden flex justify-end mb-4">
                    <button
                        onClick={() => setIsFilterOpen(true)}
                        className="flex items-center gap-2 px-4 py-2 border rounded-md text-sm bg-white dark:bg-gray-800 dark:text-gray-200 shadow-sm"
                    >
                        <FiFilter /> Filters
                    </button>
                </div>

                <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-100">
                    {selectedSubCategory || selectedCategory || 'All Products'}
                </h2>

                {/* Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                    {visibleProducts.map((item) => (
                        <div
                            key={item.id}
                            onClick={() => navigate(`/product/${item.id}`)}
                            className="cursor-pointer"
                        >
                            <ProductCard item={item} />
                        </div>
                    ))}
                </div>

                {/* Loader */}
                <div ref={loaderRef} className="flex justify-center py-6">
                    {loading && (
                        <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
                            <div className="w-5 h-5 border-2 border-t-transparent border-brand-accent rounded-full animate-spin"></div>
                            <span>Loading...</span>
                        </div>
                    )}
                </div>

                {visibleProducts.length === 0 && (
                    <p className="text-sm text-gray-500 mt-6">No products match this filter.</p>
                )}
            </main>

            {/* Mobile Filter Modal */}
            {isFilterOpen && (
                <div className="fixed inset-0 z-50 flex" onClick={() => setIsFilterOpen(false)}>
                    <div className="flex-1 bg-black/40 transition-opacity duration-300" />
                    <div
                        className="w-[80%] h-full bg-white dark:bg-gray-800 shadow-xl overflow-auto transform transition-transform duration-300"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700">
                            <h3 className="font-semibold text-gray-800 dark:text-gray-100">Filters</h3>
                            <button
                                onClick={() => setIsFilterOpen(false)}
                                className="text-sm px-3 py-1 rounded-md bg-brand-primary text-white hover:bg-brand-accent transition"
                            >
                                Done
                            </button>
                        </div>
                        <FilterSidebar onPriceChange={setPriceRange} />
                    </div>
                </div>
            )}
        </div>
    )
}

import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { login } from '../store/slices/authSlice'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const dispatch = useDispatch()
  const nav = useNavigate()

  const onSubmit = async (e) => {
    e.preventDefault()
    await dispatch(login({ email, password }))
    nav('/')
  }

  return (
    <div className="section">
      <form onSubmit={onSubmit} className="max-w-sm mx-auto card">
        <h2 className="text-xl font-semibold mb-4">Sign in</h2>
        <input className="w-full border rounded-md px-3 py-2 mb-3" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="w-full border rounded-md px-3 py-2 mb-3" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="w-full bg-brand-primary text-white py-2 rounded-md">Login</button>
      </form>
    </div>
  )
}
